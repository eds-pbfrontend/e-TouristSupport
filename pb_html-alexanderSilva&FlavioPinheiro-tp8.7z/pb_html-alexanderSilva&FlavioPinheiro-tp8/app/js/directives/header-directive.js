app.directive("headerDirective", function() {
    return {
        templateUrl : "templates/layout_header.html"
    };
});