app.directive("footerDirective", function() {
    return {
        templateUrl : "templates/layout_footer.html"
    };
});